//
//  HomeView1CollectionVc.swift
//  Demo
//
//  Created by Apple on 16/11/22.
//

import UIKit

class HomeView1CollectionVc: UICollectionViewCell {
    
    @IBOutlet weak var lblsubcategory: UILabel!
}

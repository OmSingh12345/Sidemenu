//
//  SubcategoryViewController.swift
//  Demo
//
//  Created by Apple on 16/11/22.
//

import UIKit

class SubcategoryViewController: UIViewController {

    @IBOutlet weak var tblSubcatData: UITableView!
    var subcateData = ["All","Ac service","Ac installation","fridge","refregerator"]
    var callback:(([String])->())?
    override func viewDidLoad() {
        super.viewDidLoad()

        tblSubcatData.delegate = self
        tblSubcatData.dataSource = self
    }
 
    @IBAction func btnSubmit(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
        self.callback!(subcateData)
    }
}
extension SubcategoryViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return subcateData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblSubcatData.dequeueReusableCell(withIdentifier: "SubCategoryTableViewCell", for: indexPath) as! SubCategoryTableViewCell
        let obj = subcateData[indexPath.row]
        cell.lblSubCat.text = obj
        cell.callbackSub =
        {
            
        }
        return cell
    }
    
    
}

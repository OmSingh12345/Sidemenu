//
//  DemoCollectionViewCell.swift
//  Demo
//
//  Created by Apple on 17/12/22.
//

import UIKit

class DemoCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var demoview: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

//
//  DemoCollectionViewController.swift
//  Demo
//
//  Created by Apple on 17/12/22.
//

import UIKit

class DemoCollectionViewController: UIViewController {

    var ArrName1 = ["Usman","Usman","Usman","Usman","Usman","Usman","Usman","Usman"]
    var arr2 = ["Om","Om","Om","Om","Om","Om","Om","Om"]
    @IBOutlet weak var demoCollection: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        demoCollection.delegate = self
        demoCollection.dataSource = self
        register()
    }
}
extension DemoCollectionViewController:UICollectionViewDelegate,UICollectionViewDataSource
{
    func register()
    {
        demoCollection.register(UINib(nibName: "DemoCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "DemoCollectionViewCell")
        demoCollection.register(UINib(nibName: "Demo2CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "Demo2CollectionViewCell")
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     print("\(section)")
        return ArrName1.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
        print("\(indexPath.row)")
        if indexPath.row % 2 == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DemoCollectionViewCell", for: indexPath) as! DemoCollectionViewCell
            cell.lblname.text = ArrName1[indexPath.row]
            return cell
        }
      else
        { let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Demo2CollectionViewCell", for: indexPath) as! Demo2CollectionViewCell
          cell.lblname.text = arr2[indexPath.row]
          return cell
            
        }
      
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
           let width = view.frame.width
           let height = CGFloat(200)
           
           return CGSize(width: width, height: height)
       }
    
}

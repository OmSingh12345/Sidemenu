//
//  Demo2CollectionViewCell.swift
//  Demo
//
//  Created by Apple on 17/12/22.
//

import UIKit

class Demo2CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

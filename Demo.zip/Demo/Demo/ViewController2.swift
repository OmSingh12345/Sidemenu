//
//  ViewController2.swift
//  Demo
//
//  Created by Apple on 10/11/22.
//

import UIKit
import KYDrawerController

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btngotoHome(_ sender: UIButton) {
      self.moveToHome()
 //let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController6") as! ViewController6
      //  self.navigationController?.pushViewController(vc , animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension UIViewController{
    func moveToHome(){
        let drawer = KYDrawerController.init(drawerDirection: .left, drawerWidth:UIScreen.main.bounds.width - 80)
        let initialViewController = UIStoryboard(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
      //  initialViewController.selectedIndex = index
        let nav1 = UINavigationController.init(rootViewController: initialViewController)
        nav1.isNavigationBarHidden = true
        drawer.mainViewController = nav1
        let drawerController = UIStoryboard(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "SidemenuVc") as! SidemenuVc
        let nav2 =  UINavigationController(rootViewController: drawerController)
        nav2.isNavigationBarHidden = true
        drawer.drawerViewController = nav2
        UIApplication.shared.windows.first?.rootViewController = drawer
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
}

//
//  ViewController1.swift
//  Demo
//
//  Created by Apple on 10/11/22.
//

import UIKit
import FSCalendar

class ViewController1: UIViewController,FSCalendarDelegate ,FSCalendarDataSource{
    var calendor:FSCalendar!
    var formatter = DateFormatter()
    override func viewDidLoad() {
        super.viewDidLoad()

        calendor = FSCalendar(frame: CGRect(x: 0.0, y: 40.0, width: self.view.frame.size.width, height: 300.0))
        calendor.scrollDirection = .horizontal
        calendor.scope = .month
      //  calendor.scope = .week
       // calendor.locale = Locale(identifier: "ar") // for hindi name
        self.view.addSubview(calendor)
        calendor.delegate = self
        calendor.dataSource = self
        
        //MARK: -  for changing date font size and color
        calendor.appearance.titleFont = UIFont.systemFont(ofSize: 20.0)
        calendor.appearance.headerTitleFont = UIFont.boldSystemFont(ofSize: 13.0)
        calendor.appearance.weekdayFont = UIFont.boldSystemFont(ofSize: 1)
        
        //MARK: -  for selecting multiple date
        calendor.allowsMultipleSelection = true
        calendor.allowsMultipleSelection.customMirror
    }
    
    //MARK: - for Selecting particular date
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        formatter.dateFormat = "dd-MM-yyyy"   //
        print("date selected == \(formatter.string(from:date))") // for print date
    }
 
    
  //MARK: -  not be showing past date
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
    //MARK: -  selecting 5 days after current days
//    func maximumDate(for calendar: FSCalendar) -> Date {
//        return Date().addingTimeInterval((24*60*60)*5)
//    }
    
   
    //MARK: -  for Showing number of dots under a date
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        formatter.dateFormat = "dd-MM-yyyy"
        guard let eventdate = formatter.date(from: "15-11-2022") else {return 0}
        if date.compare(eventdate ) == .orderedSame {
            return 2
        }
        return 0
    }
}

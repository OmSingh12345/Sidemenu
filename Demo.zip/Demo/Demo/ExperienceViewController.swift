//
//  ExperienceViewController.swift
//  Demo
//
//  Created by Apple on 16/11/22.
//

import UIKit

class ExperienceViewController: UIViewController {

    @IBOutlet weak var collectionview: UICollectionView!
    var Exparr = ["less than 1 year","1 year","1 to 3 year","more than 3 year","4 year","More than 4 year"]
    var callback:((String)->())?
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionview.delegate = self
        collectionview.dataSource = self
    }
    
}
extension ExperienceViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return Exparr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "ExperienceCollectionViewCell", for: indexPath) as! ExperienceCollectionViewCell
        let obj = Exparr[indexPath.row]
        cell.lblExperience.text = obj
        return cell
    }
    func collectionView(collectionView: UICollectionView,
                            layout collectionViewLayout: UICollectionViewLayout,
                            sizeForItemAtIndexPath indexPath:  NSIndexPath) -> CGSize
        {

            return CGSize(width: 150, height:50)
        }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.row
        {
        case 0:
           self.callback?("\(Exparr[0])")
           // NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: Exparr,userInfo: [0: 0])
            self.navigationController?.popViewController(animated: true)
            break
        case 1:
            self.callback?("\(Exparr[1])")
            self.navigationController?.popViewController(animated: true)
            break
        case 2:
            self.callback?("\(Exparr[2])")
            self.navigationController?.popViewController(animated: true)
            break
        case 3:
            self.callback?("\(Exparr[3])")
            self.navigationController?.popViewController(animated: true)
            break
        default:
            return
        }
    }
}

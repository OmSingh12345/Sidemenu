//
//  kydrawerfile.swift
//  Demo
//
//  Created by Apple on 10/11/22.
//

import Foundation
import KYDrawerController
import UIKit
import DropDown

let sharedSceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate
let kSharedAppDelegate          = UIApplication.shared.delegate as? AppDelegate
let kSharedInstance             = SharedClass.sharedInstance
let kSharedSceneDelegate        = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate
let kSharedUserDefaults         = UserDefaults.standard
let kScreenWidth                = UIScreen.main.bounds.size.width
let kScreenHeight               = UIScreen.main.bounds.size.height
let kRootVC                     = UIApplication.shared.windows.first?.rootViewController
let kBundleID                   = Bundle.main.bundleIdentifier!
class SharedClass: NSObject {
    static let sharedInstance = SharedClass()
    private override init() {
    }
    
}


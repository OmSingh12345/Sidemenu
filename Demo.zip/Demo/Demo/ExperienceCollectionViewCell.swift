//
//  ExperienceCollectionViewCell.swift
//  Demo
//
//  Created by Apple on 16/11/22.
//

import UIKit

class ExperienceCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lblExperience: UILabel!
    
}

//
//  ViewController6.swift
//  Demo
//
//  Created by Apple on 29/12/22.
//

import UIKit

class ViewController6: UIViewController {

    var buttonOfXib : Backbuttonxib!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setleftBarButton()
        // Do any additional setup after loading the view.
    }
    func setleftBarButton()
    {
        buttonOfXib = Backbuttonxib.instanceFromNib()
        buttonOfXib.frame = CGRect(x:0, y: 0, width: self.view.frame.width, height: navigationController?.navigationBar.frame.height ?? 20)
       // buttonOfXib.setImage(UIImage(named: "axe"), for: .normal)

        buttonOfXib.btnSideImage.addTarget(self, action: #selector(actionForSideMenu(_:)), for: .touchUpInside)
        buttonOfXib.imageSide.contentMode = .scaleAspectFit
        buttonOfXib.lblName.text = "Singh is Back Demo"
        let titleItem = UIBarButtonItem(customView: buttonOfXib)
        self.navigationItem.setLeftBarButtonItems(nil, animated: false)
        self.navigationItem.setLeftBarButtonItems([titleItem], animated: false)
    }
//    func setLeftBarButton(){
//        let button = UIButton(frame: CGRect(x:0,y: 0,width:35,height:35))
//         button.setImage(UIImage(named: "axe"), for: .normal)
//        button.setTitle("Back button", for: .normal)
//        button.tintColor = .red
//        button.addTarget(self, action: #selector(actionForSideMenu(_:)), for: .touchUpInside)
//
//        let barButtonItem = UIBarButtonItem(customView: button)
//        self.navigationItem.leftBarButtonItem = nil
//        self.navigationItem.setLeftBarButtonItems([barButtonItem], animated: false)
//    }
    @IBAction func actionForSideMenu(_ sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}

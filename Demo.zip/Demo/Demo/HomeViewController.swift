//
//  HomeViewController.swift
//  Demo
//
//  Created by Apple on 10/11/22.
//

import UIKit
import KYDrawerController

class HomeViewController: UIViewController {
    @IBOutlet weak var lblforDataCheckUsingNotification: UILabel!
    
    var emptydictionary:[String:Any] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
    }
  
    @IBAction func btnchat(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChattingVC") as! ChattingVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
        
        @objc func methodOfReceivedNotification(notification: Notification) {
            if let data = notification.userInfo
            {
                emptydictionary = data as? [String: Any] ?? [:]
                for data in emptydictionary
                { let key1 = data.key
                    let value1 = data.value
                    self.lblforDataCheckUsingNotification.text = value1 as? String
                }
            }
            else
            {
                
            }
        }
        
        
        @IBAction func btnsidemenu(_ sender: UIButton) {
            guard let drawer = kSharedAppDelegate?.drawyerController else {
                return
            }
            //  IQKeyboardManager.shared.resignFirstResponder()
            drawer.drawerDirection  = KYDrawerController.DrawerDirection.left
            drawer.setDrawerState(KYDrawerController.DrawerState.opened, animated: true)
        }
    }
    
    




//
//  SubCategoryTableViewCell.swift
//  Demo
//
//  Created by Apple on 16/11/22.
//

import UIKit

class SubCategoryTableViewCell: UITableViewCell {

    @IBOutlet weak var lblSubCat: UILabel!
    var callbackSub:(()->())?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnSubcategory(_ sender: UIButton) {
        callbackSub?()
        sender.isSelected = !sender.isSelected
    }
    
}

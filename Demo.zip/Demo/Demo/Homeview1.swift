//
//  Homeview1.swift
//  Demo
//
//  Created by Apple on 11/11/22.
//

import UIKit
import DropDown

class Homeview1: UIViewController {
    
    @IBOutlet weak var txtfieldSearch: UITextField!
    @IBOutlet weak var collectionview1: UICollectionView!
    @IBOutlet weak var tblforselect: UITableView!
    @IBOutlet weak var btnCategory: UIButton!
    @IBOutlet weak var lblcat: UILabel!
    @IBOutlet weak var lblexperience: UILabel!
    
    var getemptyExperience:[String] = []
    var getSubcategorydata:[String] = []
    var subcateData = ["All","Ac service","Ac installation","fridge","refregerator"]
    var categoryArr = ["aa","bb","cc","cb","ab"]
    var filterderdata:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        tblforselect.delegate = self
        tblforselect.dataSource = self
        collectionview1.delegate = self
        collectionview1.dataSource = self
        //  self.lblSubcat.text = getSubcategorydata.first
        
    
    NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
}
    @objc func methodOfReceivedNotification(notification: Notification) {
        if let data = notification.object
        {
//            if let getdata = notification.userInfo
//            {
//                let receive = getdata.values
//                self.getemptyExperience = data as? [String] ?? []
//                self.lblexperience.text = getemptyExperience[receive]
//            }
           
        }
    }
    
    
    
    func filterdata()
    {
        let filterd = categoryArr.filter{$0.contains("\(txtfieldSearch)")}
        self.txtfieldSearch.text = "\(filterd)"
        tblforselect.reloadData()
    }
    @IBAction func txtfieldSerchProduct(_ sender: UITextField) {
    }
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    
    @IBAction func btnSubCtegory(_ sender: UIButton) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SubcategoryViewController") as! SubcategoryViewController
//        vc.callback = { (data) in
//           print("\(data).......om........")
//            self.lblSubcat.text = "\(data)"
////            self.getSubcategorydata = data
////            print("arraydata")
////            print("\(self.getSubcategorydata)")
//            for i in data
//            {
//                print(i)
//                self.getSubcategorydata.append(i)
//            }
//        }
//
//        self.navigationController?.pushViewController(vc , animated: true)
    }
    
    @IBAction func btncategory(_ sender: UIButton) {
        
            kSharedAppDelegate?.dropDown(dataSource: categoryArr.map{($0)}, text: btnCategory) { (index, item) in
                self.lblcat.text  = item
               // let id = self.MainProductList[index]._id
              
              //  self.mainCategoryID = id
             //   self.mainProduct = true
           //     self.colorAndImageTV.reloadData()
                // self.getSubCategoryAPI(categoryID: self.categoryID ?? "")
                // self.getSubCategoryAPI(id:self.categoryID ?? "")
                
            
        }
    }
    
    @IBAction func btnback(_ sender: UIButton) {
        NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: nil, userInfo: ["Renish":"Dadhaniya"])
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnExperience(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ExperienceViewController") as! ExperienceViewController
        
        vc.callback = { data in
            
           self.lblexperience.text = data
        }
        self.navigationController?.pushViewController(vc , animated: true)
    }
    
  
}

extension Homeview1:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return  categoryArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblforselect.dequeueReusableCell(withIdentifier: "Homeview1cell") as! Homeview1cell
        let obj = categoryArr[indexPath.row]
        cell.lblcategory.text = obj
        cell.callback =
        {
            
        }
        return cell
    }
    
    
}

extension Homeview1:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return  subcateData.count
        if getSubcategorydata.count <=  subcateData.count
        {
            return  getSubcategorydata.count
        }
       // return getSubcategorydata.count == 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview1.dequeueReusableCell(withReuseIdentifier: "HomeView1CollectionVc", for: indexPath) as! HomeView1CollectionVc
        let obj = subcateData[indexPath.row]
       cell.lblsubcategory.text = obj
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SubcategoryViewController") as! SubcategoryViewController
        vc.callback = { (data) in
           print("\(data).......om........")
            for i in data
            {
                print(i)
                self.getSubcategorydata.append(i)
            }
        }
        
        self.navigationController?.pushViewController(vc , animated: true)
    }
    
}

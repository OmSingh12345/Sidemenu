//
//  OutgoingCell.swift
//  Demo
//
//  Created by Apple on 17/11/22.
//

import UIKit

class OutgoingCell: UITableViewCell {

    @IBOutlet weak var lblOutgoingMesage: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        var callback:((String)->())?
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

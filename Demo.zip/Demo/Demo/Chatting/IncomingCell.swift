//
//  IncomingCell.swift
//  Demo
//
//  Created by Apple on 17/11/22.
//

import UIKit

class IncomingCell: UITableViewCell {

    @IBOutlet weak var lblIncomingMessage: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

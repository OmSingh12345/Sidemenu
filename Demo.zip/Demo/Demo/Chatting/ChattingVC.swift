//
//  ChattingVC.swift
//  Demo
//
//  Created by Apple on 17/11/22.
//

import UIKit

class ChattingVC: UIViewController {

    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var txtfieldMessage: UITextField!
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.register()
      
    }

}
extension ChattingVC:UITableViewDelegate,UITableViewDataSource
{
   
    func register()
    {
        tableview.delegate = self
        tableview.dataSource = self
        tableview.register(UINib(nibName: "IncomingCell", bundle: nil), forCellReuseIdentifier: "IncomingCell")
        tableview.register(UINib(nibName: "OutgoingCell", bundle: nil), forCellReuseIdentifier: "OutgoingCell")
        self.tableview.estimatedRowHeight = 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "OutgoingCell", for: indexPath) as! OutgoingCell
        cell.selectionStyle = .none
        cell.lblOutgoingMesage.text = txtfieldMessage.text
        return cell
    }
    
}

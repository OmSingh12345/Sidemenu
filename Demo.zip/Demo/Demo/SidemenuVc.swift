//
//  SidemenuVc.swift
//  Demo
//
//  Created by Apple on 10/11/22.
//

import UIKit
import KYDrawerController

class SidemenuVc: UIViewController {

    @IBOutlet weak var tblViewheight: NSLayoutConstraint!
    @IBOutlet weak var tab1: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        tab1.delegate = self
        tab1.dataSource = self
    }
    override func viewWillLayoutSubviews() {
        self.tblViewheight.constant = self.tab1.contentSize.height
    }
    }
   

extension SidemenuVc:UITableViewDelegate,UITableViewDataSource
{
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tab1.dequeueReusableCell(withIdentifier: "TableViewCell1") as! TableViewCell1
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //kSharedAppDelegate?.isSideMenutapped = true
        switch indexPath.row {
        case 0:
            self.showController(controllerId: "Homeview1", storyBoard: "Home")

            break
        case 1:
            self.showController(controllerId: "ProductManagementVC", storyBoard: "Home")

            break
        case 2:
            self.showController(controllerId: "OrderManagementVC", storyBoard: "Home")
            break

        case 3:
            self.showController(controllerId: "InventoryManagementVC", storyBoard: "Home")
            break

        case 4:
            self.showController(controllerId: "SalesManagementVC", storyBoard: "Home")
            break


        default:
            return
        }
    }

    
}

extension SidemenuVc {
    //MARK:- MethodsForShowSideBar
    func showSideBar() {
        guard let drawer = kSharedAppDelegate?.drawyerController else {
            print("doesn not contenyt")
            return
        }
       // IQKeyboardManager.shared.resignFirstResponder()
        drawer.drawerWidth      = self.view.frame.width - 70
        drawer.drawerDirection  = KYDrawerController.DrawerDirection.right
        drawer.setDrawerState(KYDrawerController.DrawerState.opened, animated: true)
    }
    
    func hideSideBar() {
        guard let drawer = self.navigationController?.navigationController?.parent as? KYDrawerController else { return }
        drawer.setDrawerState(.closed, animated: true)
    }
    
    func showController(controller: UIViewController) {
      //  IQKeyboardManager.shared.resignFirstResponder()
        guard let drawer = self.navigationController?.parent as? KYDrawerController else { return }
        drawer.setDrawerState(.closed, animated: true)
        guard let mainNav = drawer.mainViewController as? UINavigationController else { return }
        mainNav.pushViewController(controller, animated: true)
    }
    
    func showController(controllerId: String, storyBoard: String) {
        let controller  = self.getController(controllerId: controllerId, storyBoard: storyBoard)
        self.showController(controller: controller)
    }
    
    func getController(controllerId: String, storyBoard: String) -> UIViewController {
        let sb      = UIStoryboard(name: storyBoard, bundle: nil)
        let vc      = sb.instantiateViewController(withIdentifier: controllerId)
        return vc
    }
    
    func showControllerForTabbar(controller: UIViewController) {
        guard let drawer = self.navigationController?.parent as? KYDrawerController else {return}
        guard let nav = drawer.mainViewController as? UINavigationController else{return}
     //  guard let nav =  tabBar.selectedViewController as? UINavigationController else {return}
        nav.pushViewController(controller, animated: true)
    }
}

//
//  Backbuttonxib.swift
//  Demo
//
//  Created by Apple on 29/12/22.
//

import UIKit
import Foundation

class Backbuttonxib: UIView {

    @IBOutlet weak var btnSideImage: UIButton!
    
    @IBOutlet weak var imageSide: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    class func instanceFromNib() -> Backbuttonxib{
        return UINib(nibName: "Backbuttonxib", bundle: nil).instantiate(withOwner: nil,options: nil)[0] as! Backbuttonxib
        
    }
}
